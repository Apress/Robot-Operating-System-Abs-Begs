#!/usr/bin/env python



class Test:

	def __init__(self):
		print "Object created"

	def execute(self,text):
		print "Input text:> ",text



