#!/usr/bin/env python

var = input("Enter the number :> ")
try:
	result = 1.0 / var
	print "Result",result

except:
	print "Unable to divide"


