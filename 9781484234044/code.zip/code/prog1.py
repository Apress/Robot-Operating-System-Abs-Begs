#!/usr/bin/env python
# -*- coding: utf-8 -*-


__author__ = "Lentin Joseph"
__copyright__ = "Copyright 2017, The Hello World Project"
__credits__ = ["Apress"]
__license__ = "GPL"
__version__ = "0.0.1"
__maintainer__ = "Lentin Joseph"
__email__ = "qboticslabs@gmail.com"
__status__ = "Development"


print 'Hello World'
